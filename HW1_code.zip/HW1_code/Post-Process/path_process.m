function path_process(x,y,x0,y0,U,V,k,t_end)

    plot(x,y,'.','markersize',20)
    xlim([0, U*t_end + x0(end)+0.5])
    ylim([y0(1)-1.5, V*cos(2*pi/k*x0(end))*t_end + y0(end)+1])
    grid on
end