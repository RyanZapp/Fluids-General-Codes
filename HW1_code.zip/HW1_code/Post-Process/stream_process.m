function stream_process(x,y,y0,U,V,k)

plot(x,y,'b-','lineWidth',1.5)
xlim([x(1), x(end)])
ylim([y0(1)-V*k/(2*U), y0(end)+V*k/(2*U)])
grid on

end