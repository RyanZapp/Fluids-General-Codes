function streak_process(x,y,U,V,k,t_end,tau,xbar,ybar)
    
    plot(x,y,'b.','markersize',10)
    %plot(x,y,'b-','linewidth',2)
    xlim([0,U*(t_end-tau(1)) + xbar + 0.25])
    ylim([ybar - 0.25*tau(end), V*max(cos(2*pi/k*(xbar-U*tau)))*t_end - tau(1) + ybar + 1.5])
    grid on
end