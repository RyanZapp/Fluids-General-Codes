%% Streamline Plots

% Run this code from the HW1_code folder

clear
clc
close all

% add proper folders to path
addpath("Source");
addpath("Post-Process");

% Define Constant Parameters
U = 1;
V = 1;
k = 1;

% Set plot resolution and domain for streamline plots
N = 1000;
x = linspace(0,2*pi,N);

% Set beginning and final time for plot animation
% Note: Set t_begin = t_end to generate a single still image
t_begin = 0;
t_end = 5;

% Set time resolution
dt = 0.1;

% Set the values of x0 and y0 you wish to plot streamlines for
x0 = 0:1:4;
y0 = 0:1:4;

% Initializee figure for plot
figure

% Set the figure title (Name property)

% Create outer time loop

for t = t_begin:dt:t_end
    % Loop over (x0,y0) tuples
    for i = 1:length(x0)
        for j = 1:length(y0)
            y = stream_still(U,V,k,x0(i),y0(j),x,t);
            
            stream_process(x,y,y0,U,V,k);
            hold on
        end
    end
    hold off
    pause(0.01)
end
% Create figure title
cap1 = sprintf("Ensemble of streamlines for t\\in [%.1f,%.1f]",t_begin,t_end);
title(cap1)

% Label the figure axes
xlabel('x','interpreter','latex','fontsize',15)
ylabel('y','interpreter','latex','fontsize',15)

%% Pathline Plots

% Run this code from the HW1_code folder

clear
clc
close all

% add proper folders to path
addpath("Source");
addpath("Post-Process");

% Define Constant Parameters
U = 1;
V = 1;
k = 1;

% Set beginning and final time for plot animation
% Note: Set t_begin = t_end to generate a single still image
t_begin = 0;
t_end = 1;

% Set time resolution
dt = 0.01;

% Set the number and identifiers (i.e. initial positions) for particles you
% want to plot the pathlines for
x0 = 0:0.25:1;
y0 = 0:1:3;



% Initializee figure for plot
figure

% Create outer time loop
for t = t_begin:dt:t_end
    % Loop over (x0,y0) tuples
    for i = 1:length(x0)
        for j = 1:length(y0)
            [x,y] = path_still(U,V,k,x0(i),y0(j),t);
            
            path_process(x,y,x0,y0,U,V,k,t_end);
            hold on
        end
    end
    hold off
    pause(0.01)
end
% Create figure title
cap1 = sprintf("Particle Paths in time for t\\in [%.1f,%.1f]",t_begin,t_end);
title(cap1)

% Label the figure axes
xlabel('x','interpreter','latex','fontsize',15)
ylabel('y','interpreter','latex','fontsize',15)

%% Streaklines

% Run this code from the HW1_code folder

clear
clc
close all

% add proper folders to path
addpath("Source");
addpath("Post-Process");

% Define Constant Parameters
U = 1;
V = 1;
k = 1;

%set xbar and ybar
xbar = 1;
ybar = 1;
% Set beginning and final time for plot animation
% Note: Set t_begin = t_end to generate a single still image
t_begin = 0;
t_end = 1;

% Set time resolution
dt = 0.007;


% Set values for tau (this represents the number of particles and the
% specific choice of particles that will be plotted
tau = 1:0.1:5;

% Initializee figure for plot
figure

% Create outer time loop
for t = t_begin:dt:t_end
    for i = 1:length(tau)
        [x,y] = streak_still(U,V,k,tau(i),t,xbar,ybar);
        
        streak_process(x,y,U,V,k,t_end,tau,xbar,ybar);
        hold on
    end
    pause(0.0001)
end

% Create figure title
cap1 = sprintf("Streaklines in time for t\\in [%.1f,%.1f]",t_begin,t_end);
title(cap1)

% Label the figure axes
xlabel('x','interpreter','latex','fontsize',15)
ylabel('y','interpreter','latex','fontsize',15)