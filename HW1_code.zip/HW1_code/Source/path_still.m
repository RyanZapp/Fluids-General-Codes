function [x,y] = path_still(U,V,k,x0,y0,t)
    % Replace with the expressions you got for x(t) and y(t)
    x = U*t + x0;
    
    y = V*cos(2*pi/k*x0)*t + y0;
end