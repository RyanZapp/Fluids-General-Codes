function [x,y] = streak_still(U,V,k,tau,t,xbar,ybar)
    % Replace with the streakline expressions you got for x(t) and y(t)
    x =  U*(t-tau) + xbar;
    
    y = V*cos(2*pi/k*(xbar-U*tau))*(t-tau) + ybar;
end