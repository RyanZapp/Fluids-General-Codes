function y = stream_still(U,V,k,x0,y0,x,t)
% Replace with the expression you got for the streamfunction
y = V*k/(2*pi*U)*(sin(2*pi/k*(x-U*t)) - sin(2*pi/k*(x0-U*t))) + y0;

end